namespace EjerccicioGA2_DidierAlvarez
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            int a, b, r;
            a = Convert.ToInt32(textBox1.Text);
            b = Convert.ToInt32(textBox2.Text);
            //Operacion
            r = a + b;
            label3.Text = r.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            label3.Text(Convert.ToInt32(textBox1.text)) -
               (Convert.ToInt32(textBox2.textt))).ToString();
        }
    }
    }

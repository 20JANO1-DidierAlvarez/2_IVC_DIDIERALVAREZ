namespace Ejercicio2_JUanArevalo_IVC_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 1;
            for (int i = 1; i <= 50; i++)
            {
                progressBar1.Value = i;
                Application.DoEvents();
                Thread.Sleep(10);
            }

            string genero = "";
            if (radioButton1.Checked)
            {
                genero = "Masculino";
            }
            if (radioButton2.Checked)
            {
                genero = "Femenino";
            }

            MessageBox.Show("Datos del Estudiante\n\n" +
                "\nNombre: " + textBox1.Text +
                "\nEdad: " + numericUpDown1.Value +
                "\nNivel Académico: " + comboBox1.Text +
                "\nFecha de Nacimiento: " + dateTimePicker1.Text +
                "\nGenero: " + genero +
                "\n\n¡Información del Estudiante Inscrito!");
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog abrir = new OpenFileDialog();

            abrir.Title = "Selcccione una Fotografía";
            abrir.Filter = "Archivos de Imagen | * .jpg; * .jpeg; * .png; * .bpm;";

            if (abrir.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(abrir.FileName);
            }
        }
    }
}
